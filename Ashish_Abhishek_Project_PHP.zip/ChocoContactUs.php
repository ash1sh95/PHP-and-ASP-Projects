 <?php
        // put your code here
session_start();

Include'ChocoModel.php';
Include'ChocoDisplay.php';
if(isset($_POST['submit'])){
    $to = "Ashish.Arun@Colostate.edu"; // this is your Email address
    $from = $_POST['email']; // this is the sender's Email address
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $subject = "Form submission";
  
    $message = $first_name . " " . $last_name . " Has following query" . "\n\n" . $_POST['message'];
   

    $headers = "From:" . $from;
    $headers2 = "From:" . $to;
//    mail($to,$subject,$message,$headers);
//    echo "Mail Sent. Thank you " . $first_name . ", we will contact you shortly.";
    //header('Location: ChocoHome.php'); 
    }
    
    $adisplay = new ChocoDisplay();
    
    $adisplay->displayPageHeader("Contact Form");
    $adisplay->displayContactusForm();
?>




<?php
     $adisplay = new ChocoDisplay();
    $adisplay->displayPageFooter();
    
?>




