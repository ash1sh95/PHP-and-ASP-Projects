<?php declare(strict_types=1);
   /*
    Alphonso Chocolates Project
    Name: Ashish Arun and Abhishek Muralidharan
    Date: 02/24/2021

   */

// automatically load required Class files

include "ChocoShoppingCart.php";
session_start();
   

// if the form element productpk is set

if (isset($_POST['product_id']))
{
    // if the session element aCart is not set

    if (!isset($_SESSION['aCart']))
    {
        // instantiate a ChocoShopCart object and store it in $_SESSION

        $_SESSION['aCart'] = new ChocoShopCart();
   
    }
    // if the form element productqty is set (if the user updates the quanity for a product in their shopping cart)

    if (isset($_POST['productqty']))
    {
        // call the updateCartItem method

       $_SESSION['aCart']->updateCartItem((int)$_POST['product_id'],(int)$_POST['productqty']);
    }
    else
    {
        // call the addCartItem method
        
        $_SESSION['aCart']->addCartItem((int)$_POST['product_id']);

    }
}
header('location:ChocoViewCart.php');
exit();
?>
