<?php declare(strict_types=1);

   /*
    Alphonso Chocolates Project
    Name: Ashish Arun and Abhishek Muralidharan
    Date: 02/24/2021

   */


include 'ChocoDisplay.php';
include'ChocoModel.php';
include'ChocoShoppingCart.php';
include 'ChocoAuthCheck.php';

session_start();

ChocoAuthCheck::isAuthenticated($_SERVER['PHP_SELF']); // get the file name of this page from $_SERVER array

// instantiate a ChocoModel object
 header('Refresh: 5; URL=ChocoMyOrder.php');
 echo '<h2>Order Deleted <br/> You will be redirected to MyOrders Page in 5 seconds.</h2>';
 echo '<h2>If you are not redirected, please <a href="ChocoMyOrder.php">Click here to visit our Store</a>.</h2>';
//    die();
 header('Location: ChocoMyOrder.php');
$aModel = new ChocoModel();

$aModel->deleteOrder((int)$_GET['order_id']);


