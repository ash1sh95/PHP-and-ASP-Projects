<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

   /*
    Alphonso Chocolates Project
    Name: Ashish Arun and Abhishek Muralidharan
    Date: 02/24/2021

   */


declare(strict_types=1);
/* 
    Purpose: 
    Author: 
    Date: March 2021
*/

class ChocoCookie
{
    // method to create cookies
    
    function setSearchCookie(string $aString) : void
    {
        // cookies are set to expire 30 days from now (given in seconds)

        $expire = time() + (60 * 60 * 5);
        setcookie('lastsearch', $aString, $expire);
    }
}
?>