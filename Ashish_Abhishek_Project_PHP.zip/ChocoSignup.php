<?php declare(strict_types=1);
   /*
    Alphonso Chocolates Project
    Name: Ashish Arun and Abhishek Muralidharan
    Date: 02/24/2021

   */
   
session_start();

include "ChocoDisplay.php";
include "ChocoModel.php";

// Set local variables to $_POST array elements (username and userpassword) or empty strings

$userLogin = (isset($_POST['Username'])) ? trim($_POST['Username']) : '';
$userPassword = (isset($_POST['psw'])) ? trim($_POST['psw']) : '';
$name = (isset($_POST['name'])) ? trim($_POST['name']) : '';
$lastname = (isset($_POST['lastname'])) ? trim($_POST['lastname']) : '';
$phone = (isset($_POST['phone'])) ? trim($_POST['phone']) : '';
$email = (isset($_POST['email'])) ? trim($_POST['email']) : '';
$redirect = (isset($_REQUEST['redirect'])) ? $_REQUEST['redirect'] : 'ChocoHome.php';
// if the form was submitted

if (isset($_POST['signup']))
{
    $aModel = new ChocoModel();


    $userList = $aModel->getUserData($userLogin, $userPassword);

    if (count($userList)==1) //If credentials check out
    {
        $redirect = (isset($_REQUEST['redirect'])) ? $_REQUEST['redirect'] : 'ChocoLogin.php';
        extract($userList[0]);  

        $userInfo = array('customer_id'=>$customer_id, 'name'=>$name);
            

        // assign the array to a session array element

        $_SESSION['userInfo'] = $userInfo;
        session_write_close(); 

        // redirect the user
        header('location:' . $redirect);
        die();

    }

    else 
    {
        // instantiate a ChocoDisplay object
        $redirect = (isset($_REQUEST['redirect'])) ? $_REQUEST['redirect'] : 'ChocoHome.php';
        $aModel->signup($name,$lastname,(int) $phone, $userLogin,$email,$userPassword, $redirect);
        echo "You are signed up successfully";
        header('location:' . $redirect);
        die();

    }
    
}  
 $aDisplay = new ChocoDisplay();

// call the displayPageHeader method

$aDisplay->displayPageHeader("Sign up Form");

// if error variable was set, display it

if (isset($error))
{
    echo '<div id="error">' . $error . '</div>';
}

// call the displaySignInForm method

$aDisplay->displaySignupForm($name,$lastname,(int) $phone,$userLogin, $email, $userPassword, $redirect);

// call the displayPageFooter method 

$aDisplay->displayPageFooter();







