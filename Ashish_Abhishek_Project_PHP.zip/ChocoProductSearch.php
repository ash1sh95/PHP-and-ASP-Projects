<?php

   /*
    Alphonso Chocolates Project
    Name: Ashish Arun and Abhishek Muralidharan
    Date: 02/24/2021

   */

 declare(strict_types=1);
/*
    Purpose: 
    Author: Ashish Arun & Abhishek 
    Date: March 2021
    Uses: ChocoDisplay, ChocoCookie, ChocoModel
 */
// automatically load required Class files
 include "ChocoModel.php";
 include"ChocoDisplay.php";
include"ChocoCookie.php";
// if the form is submitted

if (isset($_POST['search'])) 
{
    $productName =  trim($_POST['productname']);
    $brandName =  trim($_POST['brandname']);
    
    // instantiate a ChocoCookie object
    
    $aCookie = new ChocoCookie();
    
    // call the setSearchCookie method
    
    $aCookie->setSearchCookie($productName);
}

// If a previous user is visting this page

elseif (isset($_COOKIE['lastsearch'])) 
{
    $productName =  $_COOKIE['lastsearch'];
}

// If a user is visiting this page for the first time

else 
{
    $productName =  ' ';
    $brandName = ' ';
}

// instantiate a ChocoDisplay object

$aDisplay = new ChocoDisplay();

// call the displayPageHeader method

$aDisplay->displayPageHeader("Search our Product Catalog");

// call the displaySearchForm method

$aDisplay->displaySearchForm($productName,$brandName);

// if a cookie exists or the user has initiated a search

if (isset($_POST['search']) || isset($_COOKIE['lastsearch']))
{
    // instantiate a ChocoModel object

    $aModel = new ChocoModel();
    
     if ($productName !=''){
         $results = $aModel->getProductByName($productName);
     }
    else{
    
    $results = $aModel->getProductByBrand($brandName);
    }
  
    
    // call the displaySearchResults method

     $aDisplay->displaySearchResults($results);
}

// call the displayPageFooter method 

$aDisplay->displayPageFooter();

?>