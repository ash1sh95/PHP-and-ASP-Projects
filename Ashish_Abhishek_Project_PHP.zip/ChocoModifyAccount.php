<?php declare(strict_types=1);

   /*
    Alphonso Chocolates Project
    Name: Ashish Arun and Abhishek Muralidharan
    Date: 02/24/2021

   */


include 'ChocoDisplay.php';
include'ChocoModel.php';
include'ChocoShoppingCart.php';
include 'ChocoAuthCheck.php';

session_start();

ChocoAuthCheck::isAuthenticated($_SERVER['PHP_SELF']); // get the file name of this page from $_SERVER array   


$userLogin = (isset($_POST['Username'])) ? trim($_POST['Username']) : '';
$userPassword = (isset($_POST['psw'])) ? trim($_POST['psw']) : '';
$name = (isset($_POST['name'])) ? trim($_POST['name']) : '';
$lastname = (isset($_POST['lastname'])) ? trim($_POST['lastname']) : '';
$phone = (isset($_POST['phone'])) ? trim($_POST['phone']) : '';
$email = (isset($_POST['email'])) ? trim($_POST['email']) : '';
$redirect = (isset($_REQUEST['redirect'])) ? $_REQUEST['redirect'] : 'ChocoModresult.php';
$customerid = $_SESSION['userInfo']['customer_id'];

if (isset($_POST['modify'])){
  

    $aModel = new ChocoModel();


    $userList = $aModel->updateAccount($name,$lastname,(int) $phone, $userLogin,$email,$userPassword, $redirect,(int)$customerid);
    echo '<script>alert("Account updated Login Again !!!")</script>';

    header('location:' . $redirect);
        die();
}
    
 $aDisplay = new ChocoDisplay();

// call the displayPageHeader method

$aDisplay->displayPageHeader("Modify Form");

// call the displaySignInForm method

$aDisplay->displayModifyForm($name,$lastname,(int) $phone,$userLogin, $email, $userPassword, $redirect,(int)$customerid);

// call the displayPageFooter method 

$aDisplay->displayPageFooter();