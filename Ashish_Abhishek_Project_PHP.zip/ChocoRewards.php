<?php declare(strict_types=1);

   /*
    Alphonso Chocolates Project
    Name: Ashish Arun and Abhishek Muralidharan
    Date: 02/24/2021

   */


include 'ChocoDisplay.php';
include'ChocoModel.php';
include'ChocoShoppingCart.php';
include 'ChocoAuthCheck.php';

session_start();

ChocoAuthCheck::isAuthenticated($_SERVER['PHP_SELF']); // get the file name of this page from $_SERVER array    

$aModel = new ChocoModel();
$adisplay = new ChocoDisplay();

$adisplay->displayPageHeader("Rewards");
$adisplay->displayRewards();
$adisplay->displayPageFooter();
