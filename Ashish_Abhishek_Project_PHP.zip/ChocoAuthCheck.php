<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

   /*
    Alphonso Chocolates Project
    Name: Ashish Arun and Abhishek Muralidharan
    Date: 02/24/2021

   */

 declare(strict_types=1);
/*
    Purpose: Check user login
    Author: Ashish Arun & abhishek
    Date: March 2021
 */

class ChocoAuthCheck
{
    static function isAuthenticated(string $aRedirect) : void
    {
        if (!isset($_SESSION['userInfo']))
        {
            header('location: ChocoLogIn.php?redirect=' . $aRedirect);
            die();
        }
    }
}
?>