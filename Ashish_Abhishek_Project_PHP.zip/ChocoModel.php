<?php

   /*
    Alphonso Chocolates Project
    Name: Ashish Arun and Abhishek Muralidharan
    Date: 02/24/2021

   */

declare(strict_types=1);
/* 
    
    Author: Ashish Arun And Abhishek Muralidharan
    Date: March 2021
 */
    
class ChocoModel
{
    // static method to connect to the database

    private static function dbConnect() : object
    {
        $serverName = 'buscissql1901\cisweb';
        $uName = 'deepweb';
        $pWord = 'darkweb';
        $db = 'Team111DB';
    
        try
        {
            //instantiate a PDO object and set connection properties
        
            $conn = new PDO("sqlsrv:Server=$serverName; Database=$db", $uName, $pWord, array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
           
        }
        // if connection fails
    
        catch (PDOException $e)
        {
            die('Connection failed: ' . $e->getMessage());
        }
    
        //return connection object

        return $conn;
    }

    // static method to execute a query - the SQL statement to be executed, is passed to it

    private static function executeQuery(string $query)
    {
        // call the dbConnect function

        $conn = self::dbConnect();

        try
        {
            // execute query and assign results to a PDOStatement object

            $stmt = $conn->query($query);

            do
            {
                if ($stmt->columnCount() > 0)  // if rows with columns are returned
                {
                    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);  //retreive the rows as an associative array
                }
            } while ($stmt->nextRowset());
            
            // Note: the loop is intended for situations when a nonquery (e.g., Insert, Update) is followed by a query that                 returns row(s). 
           
            //call dbDisconnect() method to close the connection

            self::dbDisconnect($conn);

            return $results;
        }
        catch (PDOException $e)
        {
            //if execution fails

            self::dbDisconnect($conn);
            die ('Query failed: ' . $e->getMessage());
        }
    }
    
    // static method to close the DB connection
    
    private static function dbDisconnect($conn) : void
    {
        // closes the specfied connection and releases associated resources

        $conn = null;
    }
        
    // method to return user data
    
    function getUserData(string $aUserName, string $aUserPassword) : array
    {
        $query = <<<STR
                    Select customer_id, name
                    From customer
                    Where username = '$aUserName'
                    and password = '$aUserPassword'
                STR;
        
        return self::executeQuery($query);
    }
        function getUserData2(string $aUserName, string $aUserPassword) : array
    {
        $query = <<<STR
                    Select customer_id, name, username
                    From customer
                    Where username = '$aUserName'
                    and password = '$aUserPassword'
                STR;
        
        return self::executeQuery($query);
    }

    function getProductByName(string $aProductName) : array
    {
        $query = <<<STR
                    Select product_id, product_name, price,product_image
                    From product
                    Where product_name like '%$aProductName%'
                STR;

        return self::executeQuery($query);
    }

    function getProductDetailsByPK(int $aProductPK) : array
    {
        $query = <<<STR
                    Select p.product_id, p.product_name, p.description, 
                        p.price, p.product_image, b.brand_name
                    From product p inner join brand b on p.brand_id = b.brand_id
                    Where p.product_id = $aProductPK
            STR;

        return self::executeQuery($query);
    }
        function getProductByBrand(string $aProductName) : array
    {
        $query = <<<STR
                    Select p.product_id, p.product_name, p.description, 
                        p.price, p.product_image, b.brand_name
                    From product p inner join brand b on p.brand_id = b.brand_id
                    Where b.brand_name like '%$aProductName%'
                STR;

        return self::executeQuery($query);
    }

    function getProductInCart(string $productPKs) : array
    {
        $query = <<<STR
                    Select product_id, product_name, price
                    From product
                    Where product_id in ($productPKs)
                STR;

        return self::executeQuery($query);
    }
   
    function insertOrder(int $aContactFK): array
    {
        $query = <<<STR
                    Insert into orders(customer_id)
                    Values ($aContactFK);
                    Select SCOPE_IDENTITY() As order_id;
                STR;

        return self::executeQuery($query);
    }

    function insertOrderItem(int $aProductOrderFK, int $aProductFK, int $aOrderQty) : void
    {
            $query = <<<STR
                        Insert into orderline(order_id_fk, product_id_fk, quantity)
                        Values ($aProductOrderFK, $aProductFK, $aOrderQty)
                    STR;

        self::executeQuery($query);
    }
    
    function signup (string $name ,string $lastname,int $phone, string $username , string $email, string $password, string $aRedirect ){
        
        $query = <<<STR
                insert into customer values ('$name','$lastname','$username','$password','$email',$phone)
                STR;
        self::executeQuery($query);
        
    }
    
    function fetchOrders(int $customerid) :array{
    
        $query = <<<STR
                select o.order_id, o.order_date,p.product_name,ol.quantity 
                from orders o inner join orderline ol on o.order_id = ol.order_id_fk
                inner join product p on p.product_id = ol.product_id_fk 
                where o.customer_id = $customerid;       
                STR;
     return self::executeQuery($query);
    }
        
    function deleteOrder(int $order_id) :void
    {
   
            $query = <<<STR
                    
                       Delete from orderline where order_id_fk = $order_id;
                       Delete from orders where order_id = $order_id;
                            
            
                    STR;

        self::executeQuery($query);
        echo "Hi baba";
        echo '<script>alert("Item is deleted from your Orders")</script>';
    }
    
    function fetchShipDate(int $orderid):array {
        $query = <<<STR
                Select ship_date from ORDERS where order_id = $orderid;
                STR;
           return self::executeQuery($query);     
    }
    
    function updateAccount(string $name ,string $lastname,int $phone, string $username , string $email, string $password, string $aRedirect, int $customerid ){
                $query = <<<STR
                update customer
                set name ='$name',last_name = '$lastname',password = '$password',email = '$email',phone = $phone , username = '$username' where customer_id =$customerid;
                STR;
        self::executeQuery($query);
        
    
    }
}
?>

