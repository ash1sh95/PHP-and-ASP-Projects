<?php declare(strict_types=1);
   /*
    Alphonso Chocolates Project
    Name: Ashish Arun and Abhishek Muralidharan
    Date: 02/24/2021

   */

// automatically load required Class files

include 'ChocoDisplay.php';
include'ChocoModel.php';
include'ChocoShoppingCart.php';
include'ChocoAuthCheck.php';
session_start();

// if the session variable is not set or is empty display appropriate message; otherwise display the items

if (!isset($_SESSION['aCart']) || count($_SESSION['aCart']->getCartItems()) === 0)
{
    header('Refresh: 5; URL=ChocoProductSearch.php');
    echo '<h2>You shopping cart is empty <br /> You are being redirected to our products page.</h2>';
    echo '<h2>If you are not redirected, please <a href="ChocoProductSearch.php">Click to search for our products</a>.</h2>';
    die();
}


ChocoAuthCheck::isAuthenticated($_SERVER['PHP_SELF']); // get the file name of this page from $_SERVER array

// get a list of productIDs for the cart items; string them together delimiting with a comma

$productIDs = implode(',', array_keys($_SESSION['aCart']->getCartItems()));

// instantiate a ChocoModel object

$aModel = new ChocoModel();

//get product details for the items in the cart

$cartList = $aModel->getProductInCart($productIDs);

// instantiate a ChocoDisplay object

$aDisplay = new ChocoDisplay();

// call the displayPageHeader method

$aDisplay->displayPageHeader("Place Order");

// call the displayCheckOut method

$aDisplay->displayCheckOut($cartList);


// call the displayPageFooter method 

$aDisplay->displayPageFooter();

?>
