<!DOCTYPE html>
<html>
<head>
   <!--
     Alphonso Chocolates Project
    Name: Ashish Arun and Abhishek Muralidharan
    Date: 02/24/2021
   -->
   <meta charset="utf-8" />
   <meta name="keywords" content="Chocolates,Gourmet,Handmade" />
   <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
   <link href="OldCSS.css" rel="stylesheet" />
   <title>Alphonso Chocolates</title> 
 

</head>
        <?php
        // put your code here
        session_start();
        include'ChocoModel.php';
        Include'ChocoDisplay.php';
        
    
        ?>
 
 <?php
$aDisplay = new ChocoDisplay();

// call the displayPageHeader method

$aDisplay->displayPageHeader("Sign In Form");

?>
<p> 
<h3>About Us</h3>
<strong>Alphonso Chocolates</Strong> is a fine art chocolatier specializing in all-natural artisanal chocolates hand crafted and gourmet.
  The Chocolates are made from fair trade Belgian cacao and from soy lecithin free cacao farms in Fort Collins, Colorado. 
  Founded in 1995, as a chocolate store has evolved today into a multi brand chocolate place selling home brand along with other leading 
  Chocolate brands, Explore the world of Everything Chocolates</p>

 <section id="Displaybar">
        
  <!--
   used bootstrap for this effect of display bars
   -->
    
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="4"></li>
            </ol>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img class="d-block w-100" src="img/truffe_slider.png" alt="First slide">
                    <div class="carousel-caption d-none d-md-block">
                        <h5>Products</h5>
                    </div>
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="img/hello_slider.png" alt="Second slide">
                    <div class="carousel-caption d-none d-md-block">
                        <h5>Handmade</h5>
                    </div>
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="img/brownie_slider.png" alt="Third slide">
                    <div class="carousel-caption d-none d-md-block">
                        <h5>Casuals</h5>
                    </div>
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="img/tasse_slider.png" alt="Forth slide">
                    <div class="carousel-caption d-none d-md-block">
                        <h5>Sugar Frees</h5>
                    </div>
                </div>
             
            </div>
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </section>
      <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    
  
   
   
<?php
$aDisplay->displayPageFooter();
?>