<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 declare(strict_types=1);
   /*
    Alphonso Chocolates Project
    Name: Ashish Arun and Abhishek Muralidharan
    Date: 02/24/2021

   */

class ChocoDisplay
{
     
    function displayPageHeader(string $pageTitle)
    {
        $output = <<<ABC
                <!DOCTYPE html>
                <head>
                <meta charset="utf-8" />
                <meta name="keywords" content="Chocolates,Gourmet,Handmade,Nestle,Chocolate Store,Lindt" />
                
                <link href="OldCSS.css" rel="stylesheet" />
                 <title>Alphonso Chocolates</title> 
                    
                
                <div class="logo_img">
                <img src="img/AC_Logo_1.png" alt="AC logo" width = 200px height=200px>
                </div>
                <div class="logo_text">
                <h4>In Fort Collins, Since 1995</h4>
                </div>
                    <nav class="horizontalNavigation">
         
                    <a href="ChocoHome.php">Home</a>
                    <a href="ChocoProductSearch.php">Products</a>
                    <a href="ChocoContactUs.php">Contact us</a>
                    <a href="ChocoRewards.php">Rewards</a>
                    <a href="ChocoViewCart.php">Cart</a>
                    <a href="ChocoMyOrder.php">Orders</a>
                    <a href="ChocoLogin.php">Login</a>
                    <a href="ChocoLogout.php">Logout</a>
                    <a href="ChocoSignup.php">Sign up</a>
                    <a href="ChocoModifyAccount.php">Modify Account</a>
                </head>
          ABC;
//        
//        if (!isset($_SESSION)){
//             $output.= <<<ABC
//                     <a href="ChocoLogin.php">Login</a>
//                     <a href="ChocoRewards.php">Rewards</a>
//
//                    <a href="ChocoSignup.php">Sign up</a>
//                    </nav>
//                    </header>
//                  ABC;
//             
//             
//        }
//        else
//        {
//              $output.= <<<ABC
//                     <a href="ChocoLogout.php">Logout</a>
//                    <a href="ChocoSignup.php">Sign up</a>
//                    </nav>
//                    </header>
//                  ABC;
//        }   
//                     
                 
  
        
        echo $output;
    }
   
    // method to display page footer
    
    function displayPageFooter()
    {
       $year = date('Y');
       $output = <<<ABC
                   <footer>
                    <nav class="verticalNavigation">
                    <h1>The Store</h1>
                    <ul>
                     <li><a href="ChocoHome.php">Home</a></li>
                    <li><a href="ChocoProductSearch.php">Products</a></li>
                     <li><a href="ChocoContactUs.php">Contact us</a></li>
                     <li><a href="ChocoRewards.php">Rewards</a></li>
                     <li><a href="ChocoViewCart.php">Cart</a></li>
                     <li><a href="ChocoMyOrder.php">Orders</a></li>
                     </ul>
                     </nav>
                     <nav class="verticalNavigation">
                    <h1>Join Us</h1>
                    <ul>
                       
                    <li> <a href="ChocoLogin.php">Login</a></li>
                    <li> <a href="ChocoLogout.php">Logout</a></li>
                     <li><a href="ChocoSignup.php">Sign up</a></li>
                     <li> <a href="ChocoModifyAccount.php">Modify Account</a></li>
                     </ul>
         
                    </nav>
                    <nav class="verticalNavigation">
                    <h1>Follow us</h1>
                    <ul>
                         <a href="https://twitter.com/TheAshishArun?ref_src=twsrc%5Etfw" class="twitter-follow-button" data-show-count="false">Follow @TwitterDev</a><script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>

                        </ul>
                        </nav>
                    <section id="contactInfo">
                    <h1>Location &amp; Hours</h1>
                    <p>2226 West Elizabeth street <br />
                        Fort Collins, CO<br />
                        (970) 200 0000 </p>
                        <p>Mon - Thu: 9 a.m. - 10 p.m.<br />
                        Sat - Sun: 9 a.m. - 10 p.m.</p>
                    <p>&copy; $year - Developed by Ashish Arun &amp; Abhishek Muralidharan for CIS 665</p>
                         </section>
                        </footer>
                        </body>
                        </html>
      
      
         ABC;
        echo $output;
    }
    

        function displaySearchForm(string $aName, string $aBrand) : void
    {
        $output = <<<HTML

                    <form action="ChocoProductSearch.php" method = "post" class="searchform">
                        <h2 style="text-align: center">Alphonso Chocolate Store</h2>
                        <label for="productname">Product:</label>
                        <input type="text" name="productname" id ="productname" maxlength="50" 
                            autofocus pattern="^[a-zA-Z\s]*$" title="Letters only" value="$aName" />
                        <label for="productname">Brand:</label>
                        <input type="text" name="brandname" id ="brandname" maxlength="50" 
                            autofocus pattern="^[a-zA-Z\s]*$" title="Letters only" value="$aBrand" />
                        <p>
                            
                            <button type="submit" name ="search" value = "Search" class="allbutton">Search</button>
                        </p>
                    </form>
                HTML;
        echo $output;
    }
    
    function displaySearchResults(array $aResults): void
    {
        $count = count($aResults);
        
        if ($count == 0)
        {
            echo "<h3>No matching products found</h3>";
            return;
        }
               
        $counter = 0;

        $output = <<<HTML
                    <table id="product" class="center">
                    <tr>
                HTML;

        foreach ($aResults as $aResult) 
        {
            extract($aResult);
            $price = number_format((float)$price,2,'.',',');
        
            $output .= <<<HTML
                        <td>
                    HTML;
            
            if ($product_image != '') 
            {
                $output .= <<<HTML
                            <img src="img/$product_image" width= 240px height = 240px><br />
                        HTML;
            }
        
            $output .= <<<HTML
                        <strong> <a href="ChocoShopDetail.php?product_id=$product_id">$product_name</a> 
                            <strong> <br />
                        <i> \$$price </i> <br />
                        </td>
                    HTML;
            
            $counter ++;
            
            if ($counter === $count) 
            {
                $output .= <<<HTML
                            </tr> </table>
                        HTML;
            }
            elseif ($counter % 2 == 0) 
            {
                $output .= <<<HTML
                            </tr><tr>
                        HTML;
            }
        }

        echo $output;
    }
    
    function displayProductDetails(array $aList) : void
    {
        // extract the elements of the array

        extract($aList[0]);

        // format the price field

        $formattedPrice = number_format((float)$price, 2,'.',',');

        $output = <<<HTML
                    <div>
                    </br>
                    </br>
                        <a href="ChocoViewCart.php">[View Cart]</a>
                    </div>
                    <h2 style="text-align: center">$product_name</h2>
                    <form action="ChocoUpdateCart.php" method = "post">
                    <input type="hidden" name="product_id" value =$product_id/>
                 HTML;
          
        // include img tag if an image exists for the film

        if ($product_image !='')
        {
            $output .= <<<HTML
                        <div style="text-align:center">
                            <img src="img/$product_image" width= 360px height = 360px>
                    
                    
                        </div>
                    HTML;
        }

        $output .= <<<HTML
                        <dl>
                            <dt><h3>Description:</h3></dt>
                            <dd>$description</dd>
                            <dt><h3>Price:</h3></dt>
                            <dd>\$$formattedPrice</dd>
                            <dt><h3>Brand:</h3></dt>
                            <dd>$brand_name</dd> <br />
                         
                            <button type="submit" name="submit" value = "Add to Cart" class="allbutton">Add to Cart</button> <br />
                        </dl>

                        <p>
                            <a href="ChocoProductSearch.php">[Back to Search Page]</a>
                        </p>
                        </form>
               HTML;

        echo $output;
    }
    
    function displayShopCart(array $aList) : void
    {
        // get a count of the number of items in the cart

        $cartItems = count($aList);



        // prepare the output using heredoc syntax

        $output = <<<HTML
                    <h2 style="text-align: center">You have $cartItems product(s) in your cart</h2>
                    <table class = "center">
                        <tr>
                            <th><h4>Product</h4></th>
                            <th><h4>Quantity</h4></th>
                            <th><h4>Unit Price</h4></th>
                            <th><h4>Extended price</h4></th>
                        </tr>
                HTML;

        foreach ($aList as $aItem)
        {
            extract($aItem);
          
            $productQty = $_SESSION['aCart']->getQtyByProductID((int)$product_id);
            $extendedPrice = $productQty * $price;
            $totalPrice += $extendedPrice;
            $formattedExtendedPrice = number_format($extendedPrice, 2);
            $formattedPrice = number_format((float)$price, 2);
            
            $output .= <<<HTML
                        <tr>
                            <td>
                                $product_name
                            </td>
                            <td>
                                <form action="ChocoUpdateCart.php" method="post" >
                                    <input type="hidden" name="product_id" value="$product_id" />
                                    <input type="number" name="productqty" 
                                        value="$productQty" size="2" maxlength="2" 
                                        required="required" step = 1 min="0" max="3" title="The max you can purchase per item is 3" />
                                    <input type="submit" name=submit" value="Update Quantity" />
                                </form>
                            </td>
                            <td style="text-align: right">
                                $$formattedPrice
                            </td>
                            <td style="text-align: right">
                                $$formattedExtendedPrice
                            </td>
                        </tr>
                    HTML;
        }
        $formattedTotalPrice = number_format((float)$totalPrice,2);
        $output .= <<<HTML
                        <tr>
                            <td colspan="2" style="text-align: center">
                                <b>Total Amount: $$formattedTotalPrice</b>
                            </td>
                            <td colspan="2" style="text-align: center">
                                <form action="ChocoCheckout.php" method="post">
                                    <input type="submit" name="submit" id="proceed" value = "Proceed to Checkout" />
                                </form>
                            </td>
                        </tr>
                    </table>
                    <p style="text-align: center">
                        <a href="ChocoProductSearch.php">[Continue shopping]</a>
                    </p>
                HTML;

        // display the output

        echo $output;
    }
    
    
    
    function displayCheckOut(array $aList) : void
    {
        // get a count of the number of items in the cart

        $cartItems = count($aList);

        $contactName = $_SESSION['userInfo']['name'];

        $output = <<<HTML
                    <h2 style="text-align: center">Hi $contactName, You have $cartItems product(s) in your cart</h2>
                    <table class="center">
                        <tr>
                            <th>Product</th>
                            <th>Quantity</th>
                            <th>Unit Price</th>
                            <th>Extended price</th>
                        </tr>
                HTML;

        foreach ($aList as $aItem)
        {
            extract($aItem);
            $productQty = $_SESSION['aCart']->getQtyByProductID((int)$product_id);
            $extendedPrice = $productQty * $price;
            $totalPrice += $extendedPrice;
            $formattedExtendedPrice = number_format($extendedPrice, 2);
            $formattedPrice = number_format((float)$price, 2);
            $output .= <<<HTML
                            <tr>
                                <td>
                                    $product_name
                                </td>
                                <td style="text-align: right; font-style: normal">
                                    $productQty
                                </td>
                                <td style="text-align: right">
                                    $$formattedPrice
                                </td>
                                <td style="text-align: right">
                                    $$formattedExtendedPrice
                                </td>
                            </tr>
                        HTML;
        }
        $formattedTotalPrice = number_format($totalPrice,2);
        $output .= <<<HTML
                        <tr>
                            <td colspan="2" style="text-align: center">
                                <b>Your order total is: $$formattedTotalPrice</b>
                            </td>
                            <td colspan="2" style="text-align: center">
                            <form action="ChocoPlaceOrder.php" method="post">
                                <input type="submit" name="submit" value = "Place Order" />
                            </form>
                            </td>
                        </tr>
                    </table>
                    <p style="text-align: center">
                        <a href="ChocoProductSearch.php">[Continue shopping]</a>
                    </p>
                HTML;

        // display the output

        echo $output;
    }
    
    function displaylogInForm (string $aUserLogin, string $aUserPassword, string $aRedirect) : void
    {
        $output = <<<HTML
                    <form action="ChocoLogIn.php" class="logInForm" id="logInForm" method="post">
                    <h2 style="text-align: center">Login</h2>
                    <input type="hidden" name ="redirect" value = "$aRedirect" />
                    <label for="userlogin">Username:</label>
                    <input type="text" name="userlogin" id ="userlogin" value= "$aUserLogin" 
                        maxlength="10" autofocus="autofocus" required="true" 
                        pattern="^[\w@\.]+$" title="User Name has invalid characters" />
                    <label for="userpassword">Password:</label> 
                    <input type="password" name="userpassword" id="userpassword" value="$aUserPassword" 
                        maxlength="10" required="true" pattern="^[\w@\.]+$" 
                        title="Password has invalid characters" />
                    <p>
                        <button type="submit" name ="signin" value = "Sign in" class="signupbtn">Sign In</button> <br />
                    </p>
                    </form>
                HTML;
                
        echo $output;
    }
    
    
    function displaySignupForm(string $name ,string $lastname,int $phone, string $username , string $email, string $password, string $aRedirect) : void
    {
        $output = <<<HTML
                <form action="ChocoSignup.php" method ="post" class="signupform">
                <h2 style="text-align: center">Sign up</h2>
                <input type="hidden" name ="redirect" value = "$aRedirect" />
                <label for="Name"><b>Name</b></label>
                <input type="text" placeholder="Enter your Name" name="name"  required="true" pattern="^[a-zA-Z\s\.]{1,100}" value=$name>
                <label for="lastName"><b>Last Name</b></label>
                <input type="text" placeholder="Enter your last Name" name="lastname"  required="true" pattern="^[a-zA-Z\s\.]{1,100}" value=$lastname>
      
                <label for="PhoneNumber"><b>Phone </b></label>
                <input type="int" placeholder="Enter your Phone Number" name="phone"  required="true" pattern="^[0-9]{1,100}" min="10" max="13" value=$phone>
      
                <label for="Username"><b>Username</b></label>
                <input type="text" placeholder="Enter your Username" name="Username" pattern="^[a-zA-Z0-9_]*$"  required="true" value = $username>
      
                <label for="email"><b>Email</b></label>
                <input type="email" placeholder="Enter your Email" name="email"  required="true" value=$email>

                <label for="password"><b>Password</b></label>
                <input type="password" placeholder="Enter your Password" name="psw"  pattern="^[a-zA-Z0-9_]{8,}" required="true" title="Must contain at least at least 8 or more characters" value=$password>

              

                    <button type="button" class="cancelbtn">Cancel</button>
                    <button type="submit" name ="signup" value = "submit" class="signupbtn">Sign up</button>
                    </br>
                    <a href="ChocoLogIn.php" class="Login page"> Already a member ? Login </a>
                     </div>
                     </div>
                </form>
                HTML;
                
        echo $output;
    }
    
    
     function displayModifyForm(string $name ,string $lastname,int $phone, string $username , string $email, string $password, string $aRedirect, int $customerid) : void
    {
        $output = <<<HTML
                <form action="ChocoModifyAccount.php" method ="post" class="signupform">
                
                <h2 style="text-align: center">Modify</h2>
                <input type="hidden" name="customerid" value="$customerid" />
                <input type="hidden" name ="redirect" value = "$aRedirect" />
                <label for="Name"><b>Name</b></label>
                <input type="text" placeholder="Enter your Name" name="name"  required="true" pattern="^[a-zA-Z\s\.]{1,100}" value=$name>
                <label for="lastName"><b>Last Name</b></label>
                <input type="text" placeholder="Enter your last Name" name="lastname"  required="true" pattern="^[a-zA-Z\s\.]{1,100}" value=$lastname>
      
                <label for="PhoneNumber"><b>Phone </b></label>
                <input type="int" placeholder="Enter your Phone Number" name="phone"  required="true" pattern="^[0-9]{1,100}" min="10" max="13" value=$phone>
      
                <label for="Username"><b>Username</b></label>
                <input type="text" placeholder="Enter your Username" name="Username" pattern="^[a-zA-Z0-9_]*$"  required="true" value = $username>
      
                <label for="email"><b>Email</b></label>
                <input type="email" placeholder="Enter your Email" name="email"  required="true" value=$email>

                <label for="password"><b>Password</b></label>
                <input type="password" placeholder="Enter your Password" name="psw"  pattern="^[a-zA-Z0-9_]{8,}" required="true" title="Must contain at least at least 8 or more characters" value=$password>

              

                    <button type="button" class="cancelbtn">Cancel</button>
                    <button type="submit" name ="modify" value = "submit" class="signupbtn">Update</button>
                    </br>
                    <a href="ChocoLogIn.php" class="Login page"> Already a member ? Login </a>
                     </div>
                     </div>
                </form>
                HTML;
                
        echo $output;
    }
    
    function displayMyOrders(array $myOrders){
         
       $count = count($myOrders);
        
        if ($count == 0)
        {
            echo "<h3> You have no current orders </h3>";
            return;
        }
               
      $output = <<<HTML
                       <h2 style="text-align: center">Your Orders</h2>
                      <table class="center">              
                        <tr>
                        <th><h2>Order ID</h2></th>
                        <th><h2>Order Date</h2></th>
                        <th><h2>Product Name</h2></th>
                        <th><h2>Quantity</h2></th>
                        <th><h2>Delete Order</h2></th>
                        </tr>
       
                HTML;
         

    foreach ($myOrders as $myOrder) {
      extract ($myOrder); 
     $output .= <<<HTML
           
        <tr>
            <td><h4>
                $order_id
            </h4> </td>
            <td>
                $order_date
            </td>
            <td>
                $product_name
            </td>
            <td>
               $quantity
            </td>   
            <td>
               <a href="ChocoDeleteOrder.php?order_id=$order_id"><button type = "button">Delete </button></a>
            </td>
        
        HTML;
        }
        
        $output .= <<<HTML
                
                    </tr>
                        </table>
                HTML;
        
        echo $output;
        
    }
        function displayContactusForm(){
        $output = <<<HTML
          
                        <!DOCTYPE html>
                        <head>
                        <title>Form submission</title>
                        </head>
                        <body>
                        <h2 style="text-align: center">Contact us</h2>
                        <form action="ChocoContactUs.php" method="post" class="contactus">
                        First Name: <input type="text" name="first_name" required="true" pattern="^[a-zA-Z\s\.]{1,100}"><br>
                        Last Name: <input type="text" name="last_name" required="true" pattern="^[a-zA-Z\s\.]{1,100}"><br>
                        Email: <input type="text" name="email"><br>
                        Message:<br><textarea rows="5" name="message" cols="60"></textarea></br>
                        </br>
                        <input type="submit" name="submit" value="Submit">
                        </form>

                        </body>
                        </html> 
                
                HTML;
        
        echo $output;
    }
    
    function displayRewards(){
         $output = <<<HTML
          
                        <!DOCTYPE html>
                        <head>
                        <title>Form submission</title>
                        </head>
                        <body>
                        <h2 style="text-align: center">In Store - Rewards for members</h2>
                        
                        <p> We value our members and we want them to get more for less</p>
                        </br>
                        <p> Check out our coupons to Redeem in store offers, However, All coupons till stocks last</p>
                        <h4> Hurry Up !!!!! </h4>
                         <img src="img/AC_Rewards.png" alt="AC Rewards" width=100% height=100% >
                        </body>
                        </html> 
                
                HTML;
        
        echo $output;
    }
    
    
}