<?php declare(strict_types=1);
   /*
    Alphonso Chocolates Project
    Name: Ashish Arun and Abhishek Muralidharan
    Date: 02/24/2021

   */

// automatically load required Class files

//spl_autoload_register(function ($class_name){
//    include $class_name . '.php';
//});
include "ChocoDisplay.php";
include "ChocoModel.php";
$listPage = 'ChocoProductSearch.php';

// If productpk is not passed with page request, redirect to Shop Search Page
// Else, assign the URL parameter to a variable

if (!isset($_GET['product_id']) || !is_numeric($_GET['product_id']))
{
    header('Location:' . $listPage);
    exit();
}
else
{
    $productPK = (int) $_GET['product_id'];
}

// instantiate a ChocoModel object

$aModel = new ChocoModel();

// Call the getProductDetailsByPK method

$prodList = $aModel->getProductDetailsByPK($productPK);

// If the number of records is not 1, redirect to Store Search Page

if (count($prodList) != 1)
{
   header('Location:' . $listPage);
   exit();
}

// instantiate a ChocoDisplay object

$aDisplay = new ChocoDisplay();

// call the displayPageHeader method

$aDisplay->displayPageHeader("Product Details");

// call the displayProductDetails method

$aDisplay->displayProductDetails($prodList);

// call the displayPageFooter method 

$aDisplay->displayPageFooter();
?>
