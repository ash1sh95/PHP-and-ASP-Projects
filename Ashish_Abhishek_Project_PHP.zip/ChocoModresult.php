<?php declare(strict_types=1);


   /*
    Alphonso Chocolates Project
    Name: Ashish Arun and Abhishek Muralidharan
    Date: 02/24/2021

   */


session_start();

if(isset ($_COOKIE[session_name()]))
{
    setcookie(session_name(),"",time()-3600);
}

unset($_SESSION["customer_id"]);
unset($_SESSION["username"]);
unset($_SESSION["userInfo"]);

session_destroy();
session_write_close();

header("Refresh: 5; url=ChocoLogin.php");

echo'Account details successfully updated  ';
echo 'You are being Logged out You will be redirected to login in 5 seconds';
die();
?>