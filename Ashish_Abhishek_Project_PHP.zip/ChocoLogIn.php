<?php declare(strict_types=1);
   /*
    Alphonso Chocolates Project
    Name: Ashish Arun and Abhishek Muralidharan
    Date: 02/24/2021

   */

        
session_start();

include "ChocoDisplay.php";
include "ChocoModel.php";

// Set local variables to $_POST array elements (username and userpassword) or empty strings

$userLogin = (isset($_POST['userlogin'])) ? trim($_POST['userlogin']) : '';
$userPassword = (isset($_POST['userpassword'])) ? trim($_POST['userpassword']) : '';

$redirect = (isset($_REQUEST['redirect'])) ? $_REQUEST['redirect'] : 'ChocoHome.php';

// if the form was submitted

if (isset($_POST['signin']))
{
    $aModel = new ChocoModel();


    $userList = $aModel->getUserData($userLogin, $userPassword);

    if (count($userList)==1) //If credentials check out
    {
        extract($userList[0]);

  

        $userInfo = array('customer_id'=>$customer_id, 'name'=>$name);
        
       

        // assign the array to a session array element

        $_SESSION['userInfo'] = $userInfo;
        session_write_close(); 

        // redirect the user

        header('location:' . $redirect);
        die();
    }

    else // Otherwise, assign error message to $error
    {
        $error = 'Invalid credentials<br />Please try again';
    }
}

// instantiate a ChocoDisplay object

$aDisplay = new ChocoDisplay();

// call the displayPageHeader method

$aDisplay->displayPageHeader("Log In Form");

// if error variable was set, display it

if (isset($error))
{
    echo '<div id="error">' . $error . '</div>';
}

// call the displaySignInForm method

$aDisplay->displaylogInForm($userLogin, $userPassword, $redirect);

// call the displayPageFooter method 

$aDisplay->displayPageFooter();



