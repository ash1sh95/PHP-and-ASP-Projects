<?php declare(strict_types=1);
   /*
    Alphonso Chocolates Project
    Name: Ashish Arun and Abhishek Muralidharan
    Date: 02/24/2021

   */

// automatically load required Class files

include 'ChocoDisplay.php';
include'ChocoModel.php';
include'ChocoShoppingCart.php';
include 'ChocoAuthCheck.php';

session_start();

//check for login of the user
ChocoAuthCheck::isAuthenticated($_SERVER['PHP_SELF']); // get the file name of this page from $_SERVER array

// instantiate a ChocoModel object

$aModel = new ChocoModel();
$aDisplay = new ChocoDisplay();

$aDisplay->displayPageHeader("My orders");
$orderDetails = $aModel->fetchOrders((int)$_SESSION['userInfo']['customer_id']);


$aDisplay->displayMyOrders($orderDetails);

  

     
            


