﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//add the following namespaces

using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.SqlServer;
using ASP_Finalproject.Models;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;

namespace ASP_Finalproject.Controllers
{
    public class RestrictController : Controller
    {
        private readonly Team111dbContext _context;

        public RestrictController(Team111dbContext context)
        {
            _context = context;
        }

        [Authorize]
        public async Task<IActionResult> MyOrders()
        {
            // retrieve the user's PK from the Claims collection
            // since the PK is stored as a string, it has to be parsed to an integer

            int userPK = Int32.Parse(HttpContext.User.Claims.FirstOrDefault(x => x.Type == ClaimTypes.Sid).Value);


            // retrieve the user's orders

            var orderDetail = _context.Orderlines
                .Include(od => od.OrderIdFkNavigation)
                .Include(od => od.ProductIdFkNavigation)
                .Where(u => u.OrderIdFkNavigation.CustomerId == userPK)
                .OrderBy(d => d.OrderIdFkNavigation.OrderDate);

            return View(await orderDetail.ToListAsync());
        }

        [Authorize]
        public IActionResult CheckOut()
        {
            Console.Write("in checkout");

            return RedirectToAction("MyCart", "Shop");
        }

        [Authorize]
        public IActionResult PlaceOrder()
        {
            Cart aCart = GetCart();

            if (aCart.CartItems().Any())
            {
                int userPK = Int32.Parse(HttpContext.User.Claims.FirstOrDefault(x => x.Type == ClaimTypes.Sid).Value);

                // insert order

                Order aOrder = new Order { CustomerId = userPK, OrderDate = DateTime.Now };

                _context.Add(aOrder);
                _context.SaveChanges();

                // get the PK of the newly inserted order

                int orderPK = aOrder.OrderId;

                // insert a orderdetail for each item in the cart

                foreach (CartItem aItem in aCart.CartItems())
                {
                    Orderline aDetail = new Orderline{ ProductIdFk = aItem.Product.ProductId, Quantity = aItem.Quantity, OrderIdFk = orderPK };
                    _context.Add(aDetail);
                }

                _context.SaveChanges();

                // remove all items from cart

                aCart.ClearCart();

                SaveCart(aCart);

                return View(nameof(OrderConfirmation));
            }

            return RedirectToAction("Search", "Shop");
        }

        private IActionResult OrderConfirmation()
        {
            return View();
        }

        private Cart GetCart()
        {
            Cart aCart = HttpContext.Session.GetObject<Cart>("Cart") ?? new Cart();
            return aCart;
        }

        private void SaveCart(Cart aCart)
        {
            HttpContext.Session.SetObject("Cart", aCart);
        }
       
        [Authorize]
        public IActionResult RewardsView()
        {
            return View();
        }

        // GET: Customers/Delete/5
     public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return RedirectToAction(nameof(Index));
            }

            var product = await _context.Orderlines
                .Include(p => p.OrderIdFkNavigation)
                .FirstOrDefaultAsync(m => m.OrderlineId == id);
            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        // POST: Products/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var orderline = await _context.Orders.FindAsync(id);
            _context.Orders.Remove(orderline);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

    }
}
