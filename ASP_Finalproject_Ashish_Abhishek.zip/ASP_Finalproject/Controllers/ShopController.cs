﻿//Demo 7 - Shopping Cart; LV

using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//Add the following namespaces

using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http;
using ASP_Finalproject.Models;

namespace ASP_Finalproject.Controllers
{
    public class ShopController : Controller
    {
        private readonly Team111dbContext _context;
        public ShopController(Team111dbContext context)
        {
            _context = context;
        }

        public IActionResult ProductSearchView(string? productName, string? brandName)
        {
            var products = from p in _context.Products.Include(p => p.Brand) select p;

            if (!string.IsNullOrEmpty(productName))
            {
                products = products.Where(p => p.ProductName.Contains(productName));
            }
            if (!string.IsNullOrEmpty(brandName))
            {
                products = products.Where(p => p.Brand.BrandName.Contains(brandName));
            }


            ViewData["ProductFilter"] = productName;
            ViewData["BrandFilter"] = brandName;

            return View(products.OrderBy(p => p.ProductName).ThenBy(p => p.Brand.BrandName).ToList());
        }


        // prepare output to display details for a product
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var product = await _context.Products
                .Include(p => p.Brand)
                .FirstOrDefaultAsync(m => m.ProductId == id);
            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        // add a product to shopping cart
        public IActionResult AddToCart(int? id)
        {
            if (id == null)
            {
                return RedirectToAction(nameof(ProductSearchView));
            }

            var product = _context.Products.FirstOrDefault(p => p.ProductId == id);

            if (product == null)
            {
                return RedirectToAction(nameof(ProductSearchView));
            }

            // call to method to retrieve cart object from session state

            Cart aCart = GetCart();

            aCart.AddItem(product);

            // call to method to save cart object to session state

            SaveCart(aCart);

            return RedirectToAction(nameof(MyCart));
        }

        // prepare output to display items in cart object
        public IActionResult MyCart()
        {
            Cart aCart = GetCart();

            if (aCart.CartItems().Any())
            {
                return View(aCart);
            }

            // if the cart is empty

            return View(aCart);
        }

        // update cart - i.e., the quantity for a product in the cart
        public IActionResult UpdateCart(int? productPK, int qty)
        {
            if (productPK == null)
            {
                return RedirectToAction(nameof(ProductSearchView));
            }

            var product = _context.Products.FirstOrDefault(p => p.ProductId == productPK);

            if (product == null)
            {
                return RedirectToAction(nameof(ProductSearchView));
            }

            Cart aCart = GetCart();

            aCart.UpdateItem(product, qty);

            SaveCart(aCart);

            return RedirectToAction(nameof(MyCart));
        }

        // remove an item from the cart
        public IActionResult RemoveFromCart(int? productPK)
        {
            if (productPK == null)
            {
                return RedirectToAction(nameof(ProductSearchView));
            }

            var product = _context.Products.FirstOrDefault(p => p.ProductId == productPK);

            if (product == null)
            {
                return RedirectToAction(nameof(ProductSearchView));
            }

            Cart aCart = GetCart();

            aCart.RemoveItem(product);

            SaveCart(aCart);

            return RedirectToAction(nameof(MyCart));
        }

        //method to retrieve cart object from session state
        private Cart GetCart()
        {
            // call the session extension method GetObject
            // if a cart object doesn't exist, create a new cart object

            Cart aCart = HttpContext.Session.GetObject<Cart>("Cart") ?? new Cart();
            return aCart;
        }

        //method to save cart object to session state
        private void SaveCart(Cart aCart)
        {
            // call the session extension method SetObject

            HttpContext.Session.SetObject("Cart", aCart);
        }
    }
}
