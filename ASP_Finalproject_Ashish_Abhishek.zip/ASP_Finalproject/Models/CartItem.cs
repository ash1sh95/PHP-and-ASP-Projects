﻿// Demo 7 - Shopping Cart; LV
// Defines a shopping cart item object

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//add namespace

using System.ComponentModel.DataAnnotations;

namespace ASP_Finalproject.Models
{
    public class CartItem
    {
        public Product Product { get; set; }

        [Required(ErrorMessage = "Please enter quantity")]
        [Range(2, 20, ErrorMessage = "Please enter an amount between 1 and 3")]
        public int Quantity { get; set; }
    }
}
